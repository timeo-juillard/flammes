FLAMMES 🔥 - version web Android
Cette version fonctionne sans ordinateur une fois hébergée sur une adresse HTTPS.
Les données sont conservées dans le stockage du navigateur.
Pour l'installer comme une appli : ouvrir l'adresse dans Chrome Android > menu ⋮ > Ajouter à l'écran d'accueil.
